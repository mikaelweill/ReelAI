from firebase_admin import storage
from google.cloud import storage as google_storage

def get_video_blob(video_id: str):
    """Get the video blob from Firebase Storage.
    
    Args:
        video_id: The ID of the video in Storage
        
    Returns:
        Blob: The video blob object
        
    Raises:
        Exception: If video is not found
    """
    bucket = storage.bucket()
    blob = bucket.blob(f'videos/{video_id}')
    
    if not blob.exists():
        raise Exception(f'Video {video_id} not found in storage')
        
    return blob 