import os
import io
import logging
from openai import OpenAI
from firebase_admin import firestore
from ..models.transcript import Transcript
from ..utils.storage import get_video_blob

# Configure logging
logger = logging.getLogger(__name__)

def create_transcript_for_video(video_id: str) -> Transcript:
    """Create a transcript for a video using Whisper API.
    
    Args:
        video_id: The ID of the video to transcribe
        
    Returns:
        Transcript: The created transcript
        
    Raises:
        Exception: If transcription fails
    """
    # Check if transcript already exists
    logger.info(f"Checking for existing transcript for video: {video_id}")
    db = firestore.client()
    transcript_ref = db.collection('transcripts').document(video_id)
    transcript_doc = transcript_ref.get()
    
    if transcript_doc.exists:
        logger.info(f"Found existing transcript for video: {video_id}")
        return Transcript(**transcript_doc.to_dict())
    
    try:
        # Get video blob from Firebase Storage
        logger.info(f"Fetching video blob from storage: {video_id}")
        blob = get_video_blob(video_id)
        
        # Get video data as bytes
        logger.info("Downloading video data")
        video_data = blob.download_as_bytes()
        
        # Create file-like object
        video_file = io.BytesIO(video_data)
        video_file.name = f"{video_id}.mp4"  # OpenAI needs a filename
        
        # Initialize OpenAI client
        logger.info("Initializing OpenAI client")
        client = OpenAI()
        
        # Transcribe with Whisper
        logger.info("Starting Whisper transcription")
        transcription = client.audio.transcriptions.create(
            file=video_file,
            model="whisper-1",
            response_format="text"
        )
        logger.info("Transcription completed successfully")
        
        # Create transcript
        transcript = Transcript(
            video_id=video_id,
            content=transcription,
            status="completed"
        )
        
        # Save to Firestore
        logger.info("Saving transcript to Firestore")
        transcript_ref.set(transcript.model_dump())
        
        return transcript
            
    except Exception as e:
        logger.error(f"Failed to create transcript for video {video_id}", exc_info=True)
        # Create failed transcript
        transcript = Transcript(
            video_id=video_id,
            content="",
            status="failed",
            error=str(e)
        )
        logger.info("Saving failed transcript status to Firestore")
        transcript_ref.set(transcript.model_dump())
        raise e