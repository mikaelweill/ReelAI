from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class Transcript(BaseModel):
    """Transcript model for video transcriptions."""
    video_id: str
    content: str
    created_at: datetime = datetime.utcnow()
    status: str = "completed"  # completed, failed
    error: Optional[str] = None

    class Config:
        """Pydantic config."""
        json_encoders = {
            datetime: lambda v: v.isoformat()
        } 