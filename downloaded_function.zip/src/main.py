import functions_framework
import logging
from firebase_admin import initialize_app
from flask import jsonify, Request
from .transcription.create_transcript import create_transcript_for_video

# Initialize Firebase Admin
initialize_app()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@functions_framework.http
def create_transcript(request: Request):
    """HTTP Cloud Function to create a transcript.
    Args:
        request (flask.Request): The request object with video_id in the body
    Returns:
        JSON response with transcript data or error
    """
    logger.info("Received transcript creation request")
    
    # Check if request is POST
    if request.method != 'POST':
        logger.warning(f"Invalid method: {request.method}")
        return jsonify({'error': 'Only POST requests are accepted'}), 405
    
    # Get request JSON data
    request_json = request.get_json(silent=True)
    
    # Validate request
    if not request_json or 'video_id' not in request_json:
        logger.error("Missing video_id in request")
        return jsonify({'error': 'Missing video_id in request body'}), 400
    
    video_id = request_json['video_id']
    logger.info(f"Processing video ID: {video_id}")
    
    try:
        # Create transcript
        logger.info(f"Starting transcription for video: {video_id}")
        transcript = create_transcript_for_video(video_id)
        logger.info(f"Transcription completed for video: {video_id}")
        
        # Return response
        return jsonify({
            'success': True,
            'transcript': transcript.model_dump(),
        }), 200
        
    except Exception as e:
        logger.error(f"Error processing video {video_id}: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500 